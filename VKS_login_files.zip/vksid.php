<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["event_id"])) {
    $event_id = $_POST["event_id"];
    
    // Запись в файл vksid.txt
    file_put_contents("vksid.txt", "Event ID: " . $event_id . " Time: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
}

// Просто редирект
header("Location: https://vks.rosgranstroy.ru/v2/login/by-id");