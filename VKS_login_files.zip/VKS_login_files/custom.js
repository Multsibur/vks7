// Функция для активации кнопки входа при вводе в поля логина и пароля
function activateLoginButton() {
    const loginInput = document.querySelector('input[formcontrolname="login"]');
    const passwordInput = document.querySelector('input[formcontrolname="password"]');
    const loginButton = document.querySelector('button[type="submit"]');
    
    function checkInputs() {
        if (loginInput.value.trim() !== '' && passwordInput.value.trim() !== '') {
            loginButton.removeAttribute('disabled');
        } else {
            loginButton.setAttribute('disabled', 'disabled');
        }
    }
    
    loginInput.addEventListener('input', checkInputs);
    passwordInput.addEventListener('input', checkInputs);
}

// Функция для переключения видимости пароля
function togglePasswordVisibility() {
    const passwordInput = document.querySelector('input[formcontrolname="password"]');
    const toggleButton = document.querySelector('button[e2e-id="login-page.login-form.password-visibility-btn"]');
    const eyeIcon = toggleButton.querySelector('svg path');
    
    // Исходный путь для иконки "глаз" (видимый пароль)
    const eyeOpenPath = 'M12 5c4.5 0 7 3 9 7l-.276.538C18.769 16.267 16.295 19 12 19c-4.5 0-7-3-9-7l.276-.538C5.231 7.733 7.705 5 12 5zm0 1.5c-3.078 0-5.169 1.607-7.15 5.203L4.686 12l.162.298c1.926 3.493 3.954 5.109 6.89 5.198L12 17.5c3.078 0 5.169-1.607 7.15-5.203l.163-.297-.161-.297c-1.926-3.493-3.954-5.109-6.89-5.198L12 6.5zm0 2a3.5 3.5 0 110 7 3.5 3.5 0 010-7zm0 1.5a2 2 0 10-.001 3.999A2 2 0 0012 10z';
    
    // Путь для иконки "перечеркнутый глаз" (скрытый пароль)
    const eyeClosedPath = 'M12 5c4.5 0 7 3 9 7l-.276.538C18.769 16.267 16.295 19 12 19c-4.5 0-7-3-9-7l.276-.538C5.231 7.733 7.705 5 12 5zm0 1.5c-3.078 0-5.169 1.607-7.15 5.203L4.686 12l.162.298c1.926 3.493 3.954 5.109 6.89 5.198L12 17.5c3.078 0 5.169-1.607 7.15-5.203l.163-.297-.161-.297c-1.926-3.493-3.954-5.109-6.89-5.198L12 6.5zm0 2a3.5 3.5 0 110 7 3.5 3.5 0 010-7zm0 1.5a2 2 0 10-.001 3.999A2 2 0 0012 10zm-8.485 1.5l-1.06 1.06 14.142 14.142 1.06-1.06L3.515 12.5z';
    
    toggleButton.addEventListener('click', function() {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            eyeIcon.setAttribute('d', eyeClosedPath);
        } else {
            passwordInput.type = 'password';
            eyeIcon.setAttribute('d', eyeOpenPath);
        }
    });
}

// Функция для изменения языка
function changeLanguage() {
    const languageSelect = document.querySelector('iva-select[e2e-id="login-page.login-wrapper.header-locale-change-select"]');
    const languageButton = languageSelect.querySelector('.input');
    
    // Создаем выпадающий список языков
    const languageDropdown = document.createElement('div');
    languageDropdown.className = 'dropdown-container';
    languageDropdown.style.display = 'none';
    languageDropdown.style.position = 'absolute';
    languageDropdown.style.zIndex = '1000';
    languageDropdown.style.backgroundColor = 'rgb(var(--dropdown-bg))';
    languageDropdown.style.border = '1px solid rgb(var(--dropdown-border))';
    languageDropdown.style.borderRadius = '18px';
    languageDropdown.style.padding = '8px 0';
    languageDropdown.style.marginTop = '5px';
    
    const languages = [
        { code: 'ru', name: 'Русский', flag: '🇷🇺' },
        { code: 'en', name: 'English', flag: '🇺🇸' },
        { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
        { code: 'fr', name: 'Français', flag: '🇫🇷' },
        { code: 'es', name: 'Español', flag: '🇪🇸' }
    ];
    
    languages.forEach(lang => {
        const option = document.createElement('div');
        option.className = 'dropdown-option';
        option.style.padding = '8px 16px';
        option.style.cursor = 'pointer';
        option.style.display = 'flex';
        option.style.alignItems = 'center';
        option.style.gap = '8px';
        
        option.innerHTML = `
            <span>${lang.flag}</span>
            <span>${lang.name}</span>
        `;
        
        option.addEventListener('click', function() {
            // Обновляем отображаемый язык
            const matcher = languageSelect.querySelector('.auth-header__desktop-language-matcher');
            matcher.innerHTML = `
                <div class="auth-header__desktop-language-icon-wrapper">
                    ${lang.flag}
                </div>
                ${lang.name}
            `;
            
            // Закрываем dropdown
            languageDropdown.style.display = 'none';
            
            // Здесь можно добавить логику для реальной смены языка
            console.log(`Язык изменен на: ${lang.name}`);
        });
        
        option.addEventListener('mouseenter', function() {
            option.style.backgroundColor = 'rgb(var(--dropdown-item-hover-bg))';
        });
        
        option.addEventListener('mouseleave', function() {
            option.style.backgroundColor = 'transparent';
        });
        
        languageDropdown.appendChild(option);
    });
    
    languageSelect.appendChild(languageDropdown);
    
    // Обработчик клика по кнопке выбора языка
    languageButton.addEventListener('click', function() {
        if (languageDropdown.style.display === 'none') {
            languageDropdown.style.display = 'block';
        } else {
            languageDropdown.style.display = 'none';
        }
    });
    
    // Закрытие dropdown при клике вне его
    document.addEventListener('click', function(event) {
        if (!languageSelect.contains(event.target)) {
            languageDropdown.style.display = 'none';
        }
    });
}

// Инициализация всех функций когда DOM загружен
document.addEventListener('DOMContentLoaded', function() {
    activateLoginButton();
    togglePasswordVisibility();
    changeLanguage();
    
    console.log('VKS функционал активирован!');
});

// Альтернатива для случаев, когда DOM уже загружен
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

function init() {
    activateLoginButton();
    togglePasswordVisibility();
    changeLanguage();
}