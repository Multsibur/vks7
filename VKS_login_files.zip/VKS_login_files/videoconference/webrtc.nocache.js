su = window.su || {};
su.ivcs = window.su.ivcs || {};
su.ivcs.media = window.su.ivcs.media || {};
su.ivcs.media.ie = window.su.ivcs.media.ie || {};
var SUBSCRIPTION_STATS = ['transportType', 'availableBandwidth', 'bitrate', 'bytesReceived', 'packetsLost', 'pliCount', 'jitterBuffer', 'width', 'height', 'fps', 'startTime'];
var PUBLICATION_STATS = ['transportType', 'availableBandwidth', 'bitrate', 'bytesSent', 'rtt', 'pliCount', 'width', 'height', 'fps', 'startTime', 'layers'];
var IE_SUBSCRIPTION_STATS = ['transportType', 'availableBandwidth', 'bitrate', 'bytesReceived', 'packetsLost'];
var IE_PUBLICATION_STATS = ['transportType', 'availableBandwidth', 'bitrate', 'bytesSent', 'rtt'];
var EMPTY_STATS = {
    availableBandwidth: -1,
    transportType: null,
    localCandidateType: null,
    remoteCandidateType: null,
    video: {
        bitrate: -1,
        bytesSent: -1,
        bytesReceived: -1,
        rtt: -1,
        packetsLost: -1,
        pliCount: -1,
        jitter: -1,
        width: -1,
        height: -1,
        fps: -1,
        layers: {}
    },
    audio: {
        bitrate: -1,
        bytesSent: -1,
        bytesReceived: -1,
        rtt: -1,
        packetsLost: -1,
        jitter: -1
    },
    dataStartTime: -1,
    lastFailure: null,
    supportedStats: []
};

su.ivcs.media.createVideo = window.su.ivcs.media.createVideo || function() {
    var video = document.createElement("video");
    video.setStream = function(stream) {
        if ("srcObject" in video)
        {
            video.srcObject = stream;
        }
        else
        {
            video.src = stream ? window.URL.createObjectURL(stream) : "";
        }
    };
    video.initialize = function() {};
    return video;
};

su.ivcs.media.createAudio = window.su.ivcs.media.createAudio || function() {
    var audio = document.createElement("audio");
    audio.setStream = function(stream) {
        if ("srcObject" in audio)
        {
            audio.srcObject = stream;
        }
        else
        {
            audio.src = stream ? window.URL.createObjectURL(stream) : "";
        }
    };
    audio.initialize = function() {};
    return audio;
};

su.ivcs.media.enumerateDevices = (function() {
    const excludeDefaults = ['default', 'communications'];
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        return function(ondevices, onfailure) {
            const filterDevices = function(devices)
            {
                ondevices(devices.filter(device => !excludeDefaults.includes(device.deviceId)))
            }
            navigator.mediaDevices.enumerateDevices().then(filterDevices)["catch"](onfailure);
        };
    } else if (window.MediaStreamTrack && window.MediaStreamTrack.getSources) {
        return function(ondevices, onfailure) {
            MediaStreamTrack.getSources(function(sources) {
                var devices = [];
                for (var i = 0; i < sources.length; i++) {
                    if (excludeDefaults.includes(sources[i].id)) continue;

                    devices[devices.length] = {
                        deviceId: sources[i].id,
                        label: sources[i].label,
                        kind: (sources[i].kind === "video" ? "videoinput" : "audioinput")
                    };
                }
                ondevices(devices);
            });
        };
    } else {
        return function(ondevices, onfailure) {
            window.setTimeout(function() {
                ondevices([]);
            }, 0);
        };
    }
})();

su.ivcs.media.WebRtcClient = function(configuration) {
    this.pcFirstArgument= configuration && configuration.iceServers ? { iceServers: configuration.iceServers, bundlePolicy: 'max-bundle' } : { bundlePolicy: 'max-bundle'};
    this.pcSecondArgument = configuration && configuration.pcSecondArgument ? configuration.pcSecondArgument : { optional: [{ googIPv6: false }]};
    this.connectionTimeoutMs = configuration && configuration.connectionTimeoutMs || 5000;
    this.iceCandidateDiscoveryTimeoutMs = configuration && configuration.iceCandidateDiscoveryTimeoutMs || Infinity;
    this.uriReplacements = configuration && configuration.uriReplacements || [];
    this.primaryPublications = {};
    this.secondaryPublications = {};
    this.subscriptions = {};
};
su.ivcs.media.WebRtcClient.prototype.publishPrimary = function(uri, stream, constraints) {
    su.ivcs.media.Console.log("[" + uri + "]: publishPrimary");
    this.publish(uri, stream, constraints, this.primaryPublications);
};
su.ivcs.media.WebRtcClient.prototype.publishSecondary = function(uri, stream, constraints) {
    su.ivcs.media.Console.log("[" + uri + "]: publishSecondary");
    this.publish(uri, stream, constraints, this.secondaryPublications);
};
su.ivcs.media.WebRtcClient.prototype.publish = function(uri, stream, constraints) {
    if (window.muteMedia) // for load testing purpose
    {
        su.ivcs.media.Console.log("Media is muted - ignore publish");
        return;
    }

    su.ivcs.media.Console.log("[" + uri + "]: publish");
    var publications, content;
    if (arguments.length != 4) {
        if (window.console && window.console.warn) {
            window.console.warn("su.ivcs.media.WebRtcClient.publish is deprecated and will be removed soon, use su.ivcs.media.WebRtcClient.publishPrimary instead");
        }
        publications = this.primaryPublications;
        content = "PRIMARY";
    } else {
        publications = arguments[3];
        content = (publications === this.secondaryPublications ? "SECONDARY" : "PRIMARY");
    }
    var that = this;
    var watchdog = new su.ivcs.media.WebRtcPeerConnectionWatchdog(this.connectionTimeoutMs);
    if (!publications[uri]) {
        (function(lastFailure) {
            if (publications[uri]) {
                publications[uri].pc.close();
                publications[uri].signalling.close();
            }
            var pc;
            try {
                pc = new RTCPeerConnection(that.pcFirstArgument, that.pcSecondArgument);
            }
            catch (e) {
                // Some browsers (for instance, firefox) fail when network is unreached. So for us it is case for reconnecting.
                watchdog.timeout(e);
                return;
            }
            var signalling = new su.ivcs.media.WebRtcSignalling(uri, that.iceCandidateDiscoveryTimeoutMs, content, that.uriReplacements);
            var stats = {
                availableBandwidth: -1,
                transportType: null,
                video: {
                    bitrate: -1,
                    bytesSent: -1,
                    rtt: -1,
                    pliCount: -1,
                    layers: {}
                },
                audio: {
                    bitrate: -1,
                    bytesSent: -1,
                    rtt: -1,
                    pliCount: -1
                },
                dataStartTime: -1,
                lastFailure: lastFailure
            };
            watchdog.onTimeout = arguments.callee;
            watchdog.start(uri, pc);
            pc.onicecandidate = function(event) {
                event.candidate = that.fixLocalCandidate(event.candidate);
                if (event.candidate) {
                    su.ivcs.media.Console.log("[" + uri + "]: local Ice candidate:", event.candidate);
                }
                signalling.addLocalIceCandidate(event.candidate);
            };
            if (RTCPeerConnection.prototype.hasOwnProperty("addTrack")) {
                stream.getTracks().forEach(function(track) {
                    pc.addTrack(track, stream);
                });
                stream.onreplacetrack = function(newTrack) {

                    pc.getSenders().forEach(function(sender) {
                        var oldTrack = sender.track;
                        if (oldTrack.kind === newTrack.kind) {
                            sender.replaceTrack(newTrack).then(function() {
                                su.ivcs.media.Console.log(oldTrack.kind + " track is replaced in rtpsender from " + oldTrack.id + " (" + oldTrack.label + ") to " + newTrack.id + " (" + newTrack.label + ")");
                            }, function(reason) {
                                su.ivcs.media.Console.log(oldTrack.kind + " track is not replaced in rtpsender due to: " + reason);
                            }).catch(function(error) {
                                su.ivcs.media.Console.log(oldTrack.kind + " track replacement failed with error: " + error);
                            });

                        }
                    });
                }
            }
            else {
                pc.addStream(stream);
            }
            var createOfferSuccess = function(description) {
                if (!description) return;

                description.sdp = that.fixLocalSdp(description.sdp);
                let userAgent = navigator.userAgent.toLowerCase();
                if (userAgent.indexOf("firefox") < 0)
                {
                    // This substitute is required in IE and in Chrome for screen sharing (through Ivcs Chrome extension) only.
                    // Camera streams are published well at least in Chrome 42 and Chrome Canary 44 without any substitute.
                    description.sdp = description.sdp.replace(/sendrecv/g, "sendonly");
                }
                else
                {
                      // Bug in Media and IMP (video 0 if max-bundle is active) for firefox
                      description.sdp = description.sdp.replace("video 0", "video 9");
                      description.sdp = description.sdp.replace("audio 0", "audio 9");
                }
                if (constraints && constraints.simulcast)
                {
                    if (userAgent.match('chrome') || userAgent.match('safari'))
                    {
                        su.ivcs.media.Console.log("Enable simulcast by munging SDP");
                        description.sdp = mungeSdpForSimulcasting(description.sdp);
                    }
                    else
                    {
                        su.ivcs.media.Console.log("Cannot enable simulcast because current browser does support it");
                    }
                }
                if (constraints && constraints.maxVideoBitrate) {
                    description.sdp = description.sdp.replace(/(m=video[^\r]*\r\n)/g, "$1b=AS:" + constraints.maxVideoBitrate + "\r\nb=TIAS:" + constraints.maxVideoBitrate + "000\r\n");
                }
                if (constraints && constraints.maxAudioBitrate) {
                    description.sdp = description.sdp.replace(/(m=audio[^\r]*\r\n)/g, "$1b=AS:" + constraints.maxAudioBitrate + "\r\nb=TIAS:" + constraints.maxAudioBitrate + "000\r\n");
                }
                su.ivcs.media.Console.log("[" + uri + "]: local SDP:", description);
                var localDescriptionPromise = pc.setLocalDescription(description, function() {}, function(error) {
                    watchdog.timeout("[" + uri + "]: local SDP can't be set: " + error);
                });
                if (localDescriptionPromise)
                {
                    localDescriptionPromise.then(function(){}).catch(function(error) {
                        watchdog.timeout("[" + uri + "]: local SDP can't be set: " + error);
                    });
                }
                signalling.setLocalSdp(description.sdp);
            };
            var createOfferPromise = pc.createOffer(createOfferSuccess, watchdog.timeout, { 'offerToReceiveAudio': 0, 'offerToReceiveVideo': 0, 'OfferToReceiveAudio': 0, 'OfferToReceiveVideo': 0 });
            if (createOfferPromise)
            {
                createOfferPromise.then(createOfferSuccess).catch(watchdog.timeout);
            }
            signalling.onRemoteSdp = function(description) {
                var rtcSessionDescription = {type: description.type, sdp: description.sdp};
                if (constraints && constraints.maxVideoBitrate) {
                    rtcSessionDescription.sdp = rtcSessionDescription.sdp.replace(/(m=video[^\r]*\r\n)/g, "$1b=AS:" + constraints.maxVideoBitrate + "\r\nb=TIAS:" + constraints.maxVideoBitrate + "000\r\n");
                }
                if (constraints && constraints.maxAudioBitrate) {
                    rtcSessionDescription.sdp = rtcSessionDescription.sdp.replace(/(m=audio[^\r]*\r\n)/g, "$1b=AS:" + constraints.maxAudioBitrate + "\r\nb=TIAS:" + constraints.maxAudioBitrate + "000\r\n");
                }
                if (constraints && constraints.minVideoBitrate) {
                    var minVideoBitrate = constraints.minVideoBitrate == 0 ? -1 : constraints.minVideoBitrate;
                    rtcSessionDescription.sdp = rtcSessionDescription.sdp.replace(/a=rtpmap:([0-9]+) VP8\/90000\r\n/g, "$&a=fmtp:$1 x-google-min-bitrate=" + minVideoBitrate + "\r\n");
                }
                rtcSessionDescription.sdp = that.fixRemoteSdp(rtcSessionDescription.sdp);
                // Bug in IMP (if only one section no BUNDLE in IMP Answer)
                // safari want to see a=group:BUNDLE
                if (rtcSessionDescription.sdp.indexOf("a=group:BUNDLE") <= 0) {
                    rtcSessionDescription.sdp = rtcSessionDescription.sdp.replace("t=0 0", "t=0 0\r\na=group:BUNDLE 0");
                }
                pc.setRemoteDescription(new RTCSessionDescription(rtcSessionDescription), function() {}, function() {}); // Silly dummy callbacks are required for Firefox >= 32, otherwise Ice connection would end up with failure
            }
            signalling.onRemoteIceCandidate = function(candidate) {
                candidate = that.fixRemoteCandidate(candidate);
                su.ivcs.media.Console.log("[" + uri + "]: remote Ice candidate:", candidate);
                pc.addIceCandidate(new RTCIceCandidate(candidate), function() {}, function() {}); // Silly dummy callbacks are required for Firefox >= 32, otherwise Ice connection would end up with failure
            }
            pc.oniceconnectionstatechange = function() {
                su.ivcs.media.Console.log("[" + uri + "]: ICE connection state changed:", pc.iceConnectionState);
                that.oniceconnectionstatechange(uri, pc.iceConnectionState, false);
                switch (pc.iceConnectionState) {
                    case "connected":
                    case "completed":
                        stats.lastFailure = null;
                        watchdog.reset();
                        // wait 1 seconds to receive remote candidates
                        let currentSignalling = signalling;
                        window.setTimeout(function() {
                            currentSignalling.close();
                        }, 1000);
                        break;
                    case "failed":
                    case "disconnected":
                        watchdog.timeout("[" + uri + "]: connection disconnected");
                        break;
                }
            }
            signalling.onFailure = watchdog.timeout;
            publications[uri] = { pc: pc, signalling: signalling, watchdog: watchdog, stats: stats };
        })(null);
    }
};
su.ivcs.media.WebRtcClient.prototype.unpublish = function(uri) {
    su.ivcs.media.Console.log("[" + uri + "]: unpublish");
    if (window.console && window.console.warn) {
        window.console.warn("su.ivcs.media.WebRtcClient.unpublish is deprecated and will be removed soon, use su.ivcs.media.WebRtcClient.unpublishPrimary instead");
    }
    if (this.primaryPublications[uri]) {
        this.primaryPublications[uri].pc.close();
        this.primaryPublications[uri].signalling.close();
        this.primaryPublications[uri].watchdog.close();
        delete this.primaryPublications[uri];
    }
};
su.ivcs.media.WebRtcClient.prototype.unpublishPrimary = function(uri) {
    su.ivcs.media.Console.log("[" + uri + "]: unpublishPrimary");
    if (this.primaryPublications[uri]) {
        this.primaryPublications[uri].pc.close();
        this.primaryPublications[uri].signalling.close();
        this.primaryPublications[uri].watchdog.close();
        delete this.primaryPublications[uri];
    }
};
su.ivcs.media.WebRtcClient.prototype.unpublishSecondary = function(uri) {
    su.ivcs.media.Console.log("[" + uri + "]: unpublishSecondary");
    if (this.secondaryPublications[uri]) {
        this.secondaryPublications[uri].pc.close();
        this.secondaryPublications[uri].signalling.close();
        this.secondaryPublications[uri].watchdog.close();
        delete this.secondaryPublications[uri];
    }
};
su.ivcs.media.WebRtcClient.prototype.subscribe = function(uri, video, audio, onstream) {
    if (window.muteMedia) // for load testing purpose
    {
        su.ivcs.media.Console.log("Media is muted - ignore subscribe");
        return;
    }

    var initialOnStream = onstream;
    onstream = function(stream) {
        su.ivcs.media.enhanceStream(stream);
        initialOnStream(stream);
    };

    su.ivcs.media.Console.log("[" + uri + "]: subscribe (video: " + video  + ", audio: " + audio + ")");
    var that = this;
    var watchdog = new su.ivcs.media.WebRtcPeerConnectionWatchdog(this.connectionTimeoutMs);
    if (!this.subscriptions[uri]) {
        (function(lastFailure) {
            var stream = null;
            if (that.subscriptions[uri]) {
                that.subscriptions[uri].pc.close();
                that.subscriptions[uri].signalling.close();
            }
            var pc;
            try {
                pc = new RTCPeerConnection(that.pcFirstArgument, that.pcSecondArgument);
            }
            catch (e) {
                // Some browsers (for instance, firefox) fail when network is unreached. So for us it is case for reconnecting.
                watchdog.timeout(e);
                return;
            }
            var signalling = new su.ivcs.media.WebRtcSignalling(uri, that.iceCandidateDiscoveryTimeoutMs, "PRIMARY", that.uriReplacements);
            var stats = {
                availableBandwidth: -1,
                transportType: null,
                video: {
                    bitrate: -1,
                    bytesReceived: -1,
                    packetsLost: -1,
                    pliCount: -1
                },
                audio: {
                    bitrate: -1,
                    bytesReceived: -1,
                    packetsLost: -1,
                    pliCount: -1
                },
                dataStartTime: -1,
                lastFailure: lastFailure
            };
            watchdog.onTimeout = arguments.callee;
            watchdog.start(uri, pc);
            pc.onicecandidate = function(event) {
                event.candidate = that.fixLocalCandidate(event.candidate);
                if (event.candidate) {
                    su.ivcs.media.Console.log("[" + uri + "]: local Ice candidate:", event.candidate);
                }
                signalling.addLocalIceCandidate(event.candidate);
            }
            if (!RTCPeerConnection.prototype.hasOwnProperty("ontrack"))
            {
                pc.onaddstream = function(event) {
                    su.ivcs.media.Console.log("[" + uri + "]: stream added:", event.stream);
                    if (pc.iceConnectionState == "connected" || pc.iceConnectionState == "completed") {
                        onstream(event.stream);
                    } else {
                        stream = event.stream;
                    }
                }
            }
            pc.ontrack = function(event) {
                su.ivcs.media.Console.log("[" + uri + "]: track added:", event.track.kind, event.streams);
                if (pc.iceConnectionState == "connected" || pc.iceConnectionState == "completed") {
                    onstream(event.streams[0]);
                } else {
                    stream = event.streams[0];
                }
            }
            if (pc.addTransceiver)
            {
                if (audio) pc.addTransceiver('audio', {direction: "recvonly"});
                if (video) pc.addTransceiver('video', {direction: "recvonly"});
            }
            var createOfferSuccess = function(description) {
                if (!description) return;

                description.sdp = that.fixLocalSdp(description.sdp);
                su.ivcs.media.Console.log("[" + uri + "]: local SDP:", description);
                var localDescriptionPromise = pc.setLocalDescription(description, function() {}, function(error) {
                    watchdog.timeout("[" + uri + "]: local SDP can't be set: " + error);
                });
                // Fix firefox video 0 to video 9 (remove after media fixed)
                let userAgent = navigator.userAgent.toLowerCase();
                if (userAgent.indexOf("firefox") > 0)
                {
                    description.sdp = description.sdp.replace("video 0", "video 9");
                    description.sdp = description.sdp.replace("audio 0", "audio 9");
                }
                //
                if (localDescriptionPromise)
                {
                    localDescriptionPromise.then(function(){}).catch(function(error)
                    {
                        watchdog.timeout("[" + uri + "]: local SDP can't be set: " + error);
                    })
                }
                signalling.setLocalSdp(description.sdp);
            };
            var createOfferPromise = pc.createOffer(createOfferSuccess, watchdog.timeout, { 'offerToReceiveAudio': !!audio, 'offerToReceiveVideo': !!video, 'OfferToReceiveAudio': !!audio, 'OfferToReceiveVideo': !!video });
            if (createOfferPromise)
            {
                createOfferPromise.then(createOfferSuccess).catch(watchdog.timeout);
            }
            signalling.onRemoteSdp = function(description) {
                var rtcSessionDescription = {type: description.type, sdp: description.sdp};
                rtcSessionDescription.sdp = that.fixRemoteSdp(rtcSessionDescription.sdp);
                // Bug in IMP (if only one section no BUNDLE in IMP Answer)
                // safari want to see a=group:BUNDLE
                if (rtcSessionDescription.sdp.indexOf("a=group:BUNDLE") <= 0) {
                    rtcSessionDescription.sdp = rtcSessionDescription.sdp.replace("t=0 0", "t=0 0\r\na=group:BUNDLE 0");
                }
                su.ivcs.media.Console.log("[" + uri + "]: remote SDP:", rtcSessionDescription);
                pc.setRemoteDescription(new RTCSessionDescription(rtcSessionDescription), function() {}, function() {}); // Silly dummy callbacks are required for Firefox >= 32, otherwise Ice connection would end up with failure
            }
            signalling.onRemoteIceCandidate = function(candidate) {
                candidate = that.fixRemoteCandidate(candidate);
                su.ivcs.media.Console.log("[" + uri + "]: remote Ice candidate:", candidate);
                pc.addIceCandidate(new RTCIceCandidate(candidate), function() {}, function() {}); // Silly dummy callbacks are required for Firefox >= 32, otherwise Ice connection would end up with failure
            }
            pc.oniceconnectionstatechange = function() {
                su.ivcs.media.Console.log("[" + uri + "]: ICE connection state changed:", pc.iceConnectionState);
                that.oniceconnectionstatechange(uri, pc.iceConnectionState, true);
                switch (pc.iceConnectionState) {
                    case "connected":
                    case "completed":
                        stats.lastFailure = null;
                        watchdog.reset();
                        // wait 1 seconds to receive remote candidates
                        let currentSignalling = signalling;
                        window.setTimeout(function() {
                            currentSignalling.close();
                        }, 1000);
                        if (stream) {
                            onstream(stream);
                            stream = null;
                        }
                        break;
                    case "failed":
                    case "disconnected":
                        watchdog.timeout("[" + uri + "]: connection disconnected");
                        break;
                }
            }
            signalling.onFailure = watchdog.timeout;
            that.subscriptions[uri] = { pc: pc, signalling: signalling, watchdog: watchdog, stats: stats };
        })(null);
    }
};
su.ivcs.media.WebRtcClient.prototype.unsubscribe = function(uri) {
    su.ivcs.media.Console.log("[" + uri + "]: unsubscribe");
    if (this.subscriptions[uri]) {
        this.subscriptions[uri].pc.close();
        this.subscriptions[uri].signalling.close();
        this.subscriptions[uri].watchdog.close();
        delete this.subscriptions[uri];
    }
};
su.ivcs.media.WebRtcClient.prototype.getStats = (function() {
    return !window.RTCPeerConnection || !window.RTCPeerConnection.prototype.getStats || window.navigator.userAgent.match('Edge') ? null : function(uri) {
        var that = this;
        var connection = (that.subscriptions[uri] || that.primaryPublications[uri]);

        if (!connection) {
            return EMPTY_STATS;
        }
        if (!connection.statsAccessTimestamp) {
            connection.stats.lastFramesSent = 0;
            connection.stats.lastFramesReceived = 0;
            connection.stats.lastReceivedTimestamp = new Date().getTime();
            connection.stats.lastSentTimestamp = new Date().getTime();
            var intervalId = window.setInterval(function() {

                if (Math.abs(new Date().getTime() - connection.statsAccessTimestamp) > 3 * 1000) {
                    window.clearInterval(intervalId);
                    connection.statsAccessTimestamp = 0;
                } else {
                    connection.pc.getStats(null).then(function (stats) {
                        if (!stats.forEach)
                        {
                            window.console.warn("RTCStatsReport does not support forEach");
                            return;
                        }

                        var audioBytesSent = 0;
                        var isIncoming = !!that.subscriptions[uri];
                        connection.stats.video.pliCount = 0;
                        connection.stats.video.width = 0;
                        connection.stats.video.height = 0;
                        var layers = {};
                        stats.forEach(function (report) {
                            if (isIncoming)
                            {
                                if (report.type === "inbound-rtp") {
                                    if (report.mediaType === "audio") {
                                        if (connection.stats.audio.bytesReceived > 0) {
                                            connection.stats.audio.bitrate = Math.round((report.bytesReceived - connection.stats.audio.bytesReceived) * 8);
                                        }
                                        connection.stats.audio.bytesReceived = parseInt(report.bytesReceived, 10);
                                        connection.stats.audio.packetsLost = parseInt(report.packetsLost, 10);
                                    }
                                    if (report.mediaType === "video") {
                                        if (connection.stats.video.bytesReceived > 0) {
                                            connection.stats.video.bitrate = Math.round((report.bytesReceived - connection.stats.video.bytesReceived) * 8);
                                        }
                                        connection.stats.video.bytesReceived = parseInt(report.bytesReceived, 10);
                                        connection.stats.video.packetsLost = parseInt(report.packetsLost, 10);
                                        connection.stats.video.pliCount = parseInt(report.pliCount, 10);
                                    }
                                }
                                if (report.type === "track") {
                                    if (report.kind === "video") {
                                        connection.stats.video.width = report.frameWidth;
                                        connection.stats.video.height = report.frameHeight;
                                        connection.stats.video.fps = Math.round((report.framesReceived - connection.stats.lastFramesReceived) / ((report.timestamp - connection.stats.lastReceivedTimestamp) / 1000));
                                        connection.stats.lastReceivedTimestamp = report.timestamp;
                                        connection.stats.lastFramesReceived = report.framesReceived;
                                    }
                                }
                                if (report.type === "local-candidate") {

                                    connection.stats.transportType = report.protocol;
                                    connection.stats.localCandidateType = report.candidateType;
                                }
                                if (report.type === "remote-candidate") {

                                    connection.stats.transportType = report.protocol;
                                    connection.stats.remoteCandidateType = report.candidateType;
                                }
                                if (report.type === "candidate-pair") {

                                    connection.stats.availableBandwidth = Math.round(report.availableIncomingBitrate);
                                }

                                connection.stats.supportedStats = SUBSCRIPTION_STATS;
                            }
                            else {
                                if (report.type === "outbound-rtp") {
                                    if (report.mediaType === "audio") {
                                        audioBytesSent += report.bytesSent;
                                    }
                                    if (report.mediaType === "video") {
                                        //Collect layers
                                        let oldLayer = connection.stats.video.layers[report.id];
                                        var layer = {};
                                        layer.id = report.id;
                                        layer.width = report.frameWidth;
                                        layer.height = report.frameHeight;
                                        layer.bytesSent = report.bytesSent;
                                        layer.lastSentTimestamp = report.timestamp;
                                        layer.lastFramesSent = report.framesSent;
                                        if (oldLayer)
                                        {
                                            layer.bitrate = Math.round((report.bytesSent - oldLayer.bytesSent) * 8);
                                            layer.fps = Math.round((report.framesSent - oldLayer.lastFramesSent) / ((report.timestamp - oldLayer.lastSentTimestamp) / 1000));
                                        }
                                        layers[report.id] = layer;

                                        connection.stats.video.pliCount += parseInt(report.pliCount, 10);
                                    }
                                }

                                if (report.type === "candidate-pair") {

                                    connection.stats.availableBandwidth = Math.round(report.availableOutgoingBitrate);
                                }
                                if (report.type === "local-candidate") {

                                    connection.stats.transportType = report.protocol;
                                    connection.stats.localCandidateType = report.candidateType;
                                }
                                if (report.type === "remote-candidate") {

                                    connection.stats.transportType = report.protocol;
                                    connection.stats.remoteCandidateType = report.candidateType;
                                }

                                connection.stats.supportedStats = PUBLICATION_STATS;
                            }
                            if (report.type === "remote-inbound-rtp") {
                                if (report.kind === "audio") {
                                    connection.stats.audio.rtt = report.roundTripTime * 1000;
                                }
                                if (report.kind === "video") {
                                    connection.stats.video.rtt = report.roundTripTime * 1000;
                                }
                            }
                            if (report.type === "track") {
                                if (report.kind === "audio") {
                                    connection.stats.audio.jitterBuffer = (report.jitterBufferDelay / report.jitterBufferEmittedCount * 1000).toFixed(0);
                                }
                                if (report.kind === "video") {
                                    connection.stats.video.jitterBuffer = (report.jitterBufferDelay / report.jitterBufferEmittedCount * 1000).toFixed(0);
                                }
                            }

                            if (connection.stats.audio.bitrate <= 0 && connection.stats.video.bitrate <= 0)
                            {
                                connection.stats.dataStartTime = -1;
                            }
                            else if (connection.stats.dataStartTime === -1)
                            {
                                connection.stats.dataStartTime = new Date().getTime();
                            }
                        });
                        //Collect publish total
                        if (!isIncoming)
                        {
                            var totalVideoBitrate = 0;
                            var totalVideoBytesSent = 0;
                            Object.values(layers).forEach(layer =>
                            {
                                //Collect only max video stats by video resolution
                                if (connection.stats.video.width * connection.stats.video.height < layer.width * layer.height)
                                {
                                    connection.stats.video.width = layer.width;
                                    connection.stats.video.height = layer.height;
                                    connection.stats.video.fps = layer.fps;
                                }
                                totalVideoBitrate += layer.bitrate;
                                totalVideoBytesSent += layer.bytesSent;
                            });
                            connection.stats.video.bitrate = totalVideoBitrate;
                            connection.stats.video.bytesSent = totalVideoBytesSent;
                            connection.stats.video.layers = layers;

                            connection.stats.audio.bitrate = Math.round((audioBytesSent - connection.stats.audio.bytesSent) * 8);
                            connection.stats.audio.bytesSent = audioBytesSent;
                        }
                    });
                }
            }, 1000);
        }
        connection.statsAccessTimestamp = new Date().getTime();
        return connection.stats;
    };
})();
su.ivcs.media.WebRtcClient.prototype.fixLocalSdp = function(sdp) {
    if (su.ivcs.media.ie.fixLocalSdp) {
        sdp = su.ivcs.media.ie.fixLocalSdp(sdp)
    }
    return sdp.replaceAll('packetization-mode=','sps-pps-idr-in-keyframe=1;packetization-mode=');
};
su.ivcs.media.WebRtcClient.prototype.fixRemoteSdp = function(sdp) {
    if (su.ivcs.media.ie.fixRemoteSdp) {
        sdp = su.ivcs.media.ie.fixRemoteSdp(sdp)
    }
    return sdp.replace(/a=rtpmap:([0-9]+) VP8\/90000\r\n/g, "$&a=fmtp:$1 x-google-start-bitrate=5491.424\r\n");
};
su.ivcs.media.WebRtcClient.prototype.fixLocalCandidate = function(candidate) {
    if (su.ivcs.media.ie.fixLocalCandidate) {
        candidate = su.ivcs.media.ie.fixLocalCandidate(candidate)
    }
    return candidate;
};
su.ivcs.media.WebRtcClient.prototype.fixRemoteCandidate = function(candidate) {
    if (su.ivcs.media.ie.fixRemoteCandidate) {
        candidate = su.ivcs.media.ie.fixRemoteCandidate(candidate)
    }
    return candidate;
};
su.ivcs.media.WebRtcClient.prototype.oniceconnectionstatechange = function(uri, state, remote) {} // TODO: Third argument should be removed in the future...

su.ivcs.media.WebRtcSignalling = function(uri, iceCandidatesWaitTimeoutMs, content, uriReplacements) {
    this.content = content;
    this.uriReplacements = uriReplacements || [];
    this.sdp = null;
    this.candidates = [];
    this.exchanged = false;
    this.xhr = window.XDomainRequest ? new XDomainRequest() : new XMLHttpRequest();
    this.xhr.responseTextOfset = 0;
    this.uri = uri;
    this.iceCandidatesWaitTimeoutMs = iceCandidatesWaitTimeoutMs;
    this.forceExchange = false;
    var that = this;
    that.xhr.open("POST", uri.replace(/^webrtc/, "http"), true);
    that.xhr.onreadystatechange = function() {
        if ((that.xhr.readyState == 3 || that.xhr.readyState == 4) && that.xhr.status != 0) { // xhr.status == 0 if aborted...
            if (that.xhr.status >= 200 && that.xhr.status < 300) {
                that.xhr.onprogress();
            } else {
                that.xhr.onreadystatechange = that.xhr.onerror = null;
                that.onFailure("[" + uri + "]: can't exchange SDPs and Ice candidates, HTTP response status code: " + that.xhr.status);
            }
        }
    }
    that.xhr.onerror = function(error) {
        that.xhr.onreadystatechange = that.xhr.onerror = null;
        that.onFailure("[" + uri + "]: can't exchange SDPs and Ice candidates due to general network failure");
    }
    that.xhr.onprogress = function() {
        if (that.xhr.status === undefined || that.xhr.status === 200) {
            while (true) {
                var responseText = that.xhr.responseText.substring(that.xhr.responseTextOfset);
                var newlineIndex = responseText.indexOf('\n');
                if (newlineIndex == -1) {
                    break;
                }
                var message = responseText.substring(0, newlineIndex + 1);
                if (message.replace(/^\s+|\s+$/g, "").length) { // String.trim() isn't supported in IE8
                    var object = JSON.parse(message);
                    if (object.sdp) {
                        if (object.type) {
                            that.processRemoteSdp(new RTCSessionDescription(object));
                        } else {
                            that.processRemoteSdp(new RTCSessionDescription({ sdp: object.sdp, type: "answer" })); // TODO: Remote this depricated code, when XAgent is ready
                        }
                    } else {
                        that.processRemoteIceCandidate(object.candidate);
                    }
                }
                that.xhr.responseTextOfset += message.length;
            }
        }
    }
    that.xhr.onload = that.xhr.onprogress;
};
su.ivcs.media.WebRtcSignalling.prototype.setLocalSdp = function(sdp) {
    var that = this;
    this.sdp = sdp;
    this.exchange();
    if (this.iceCandidatesWaitTimeoutMs > 0 && this.iceCandidatesWaitTimeoutMs < Infinity) {
        this.timeoutId = window.setTimeout(function() {
            su.ivcs.media.Console.log("[" + that.uri + "]: Ice candidate discovery timeout, force exchange SDP and Ice candidates");
            that.forceExchange = true;
            that.exchange();
        }, this.iceCandidatesWaitTimeoutMs);
    }
};
su.ivcs.media.WebRtcSignalling.prototype.addLocalIceCandidate = function(candidate) {
    this.candidates[this.candidates.length] = candidate;
    this.exchange();
};
su.ivcs.media.WebRtcSignalling.prototype.processRemoteSdp = function(sdp) {
    this.onRemoteSdp(sdp);
};
su.ivcs.media.WebRtcSignalling.prototype.processRemoteIceCandidate = function(candidate) {
    this.onRemoteIceCandidate(candidate);

    var additionalCandidateStr = this.getAdditionalCandidate(candidate.candidate);
    if (additionalCandidateStr)
    {
        su.ivcs.media.Console.log("New additional candidate suggested: " + additionalCandidateStr);
        candidate.candidate = additionalCandidateStr;
        this.onRemoteIceCandidate(candidate);
    }
};
su.ivcs.media.WebRtcSignalling.prototype.onRemoteSdp = {};
su.ivcs.media.WebRtcSignalling.prototype.onRemoteIceCandidate = {};
su.ivcs.media.WebRtcSignalling.prototype.onFailure = {};
su.ivcs.media.WebRtcSignalling.prototype.close = function() {
    this.xhr.abort();
    this.exchanged = true;
    if (this.timeoutId) {
        window.clearTimeout(this.timeoutId);
    }
}
su.ivcs.media.WebRtcSignalling.prototype.getAdditionalCandidate = function(initialCandidate) {
    for (var index = 0; index < this.uriReplacements.length; index++)
    {
        var uriReplacement = this.uriReplacements[index];
        var key = uriReplacement.key;
        if (key.startsWith("rtp://"))
        {
            key = key.substring(6);
            if (initialCandidate.toLowerCase().indexOf(key) >= 0 && uriReplacement.replacementAddress)
            {
                return initialCandidate.replace(key, uriReplacement.replacementAddress);
            }
        }
    }
    return null;
}
su.ivcs.media.WebRtcSignalling.prototype.exchange = function() {
    if (!this.exchanged && this.sdp) {
        if (this.candidates.length > 0 && (!this.candidates[this.candidates.length - 1] || this.forceExchange)) {
            this.xhr.send(JSON.stringify({ content: this.content, sdp: this.sdp, candidates: this.candidates.slice(0, this.candidates.length - 1) }));
            this.exchanged = true;
            su.ivcs.media.Console.log("[" + this.uri + "]: exchange SDP and Ice candidates");
        }
    }
}

su.ivcs.media.WebRtcPeerConnectionWatchdog = function(delay) {
    this.closed = false;
    this.timeout = this.timeout.bind(this);
    this.retryDelayMs = 100;
    this.delay = delay;
};
su.ivcs.media.WebRtcPeerConnectionWatchdog.prototype.timeout = function(reason) {
    if (!this.closed) {
        if (this.timeoutId) {
            window.clearTimeout(this.timeoutId);
        }
        if (this.pingIntervalId) {
            window.clearInterval(this.pingIntervalId);
        }
        var onTimeout = this.onTimeout;
        su.ivcs.media.Console.log(reason + ", retry in " + this.retryDelayMs + "ms");
        this.timeoutId = window.setTimeout(function() { // We have to wrap this.onTimeout to a function because setTimeout in IE 9 and below doesn't pass additional parameters to the specified function
            onTimeout(reason);
        }, this.retryDelayMs);
        this.retryDelayMs = this.retryDelayMs * 2;
        if (this.retryDelayMs > 3000) {
            this.retryDelayMs = 3000;
        }
    }
};
su.ivcs.media.WebRtcPeerConnectionWatchdog.prototype.onTimeout = {};
su.ivcs.media.WebRtcPeerConnectionWatchdog.prototype.start = function(uri, pc) {
    var that = this;
    if (this.timeoutId) {
        window.clearTimeout(this.timeoutId);
    }
    if (this.pingIntervalId) {
        window.clearInterval(this.pingIntervalId);
    }
    this.timeoutId = window.setTimeout(function() {
        that.timeout("[" + uri + "]: connection timeout");
    }, this.delay);
    var userAgent = window.navigator.userAgent.toLowerCase();
    if (userAgent.match('firefox') && parseInt(userAgent.match(/firefox\/(.*)/)[1], 10) < 63) {
        su.ivcs.media.Console.log("[" + uri + "]: open ping data channel");
        var ping = 0;
        var pong = 0;
        var dc = pc.createDataChannel("ping", {});
        dc.onmessage = function(event) {
            pong = parseInt(event.data);
        }
        dc.onopen = function(event) {
            su.ivcs.media.Console.log("[" + uri + "]: ping data channel is opened");
            that.pingIntervalId = window.setInterval(function() {
                if (ping - pong > 3) {
                    that.timeout("[" + uri + "]: connection failed (last ping response was received more than 3 seconds ago)");
                } else {
                    dc.send(ping++);
                }
            }, 1000);
        }
    }
};
su.ivcs.media.WebRtcPeerConnectionWatchdog.prototype.reset = function() {
    if (this.timeoutId) {
        window.clearTimeout(this.timeoutId);
    }
    this.retryDelayMs = 100;
};
su.ivcs.media.WebRtcPeerConnectionWatchdog.prototype.close = function() {
    if (this.timeoutId) {
        window.clearTimeout(this.timeoutId);
    }
    if (this.pingIntervalId) {
        window.clearInterval(this.pingIntervalId);
    }
    this.closed = true;
};

su.ivcs.media.Console = {};
su.ivcs.media.Console.log = function() {
    if (su.ivcs.media.Console.enabled && window.console && window.console.log) {
        var date = new Date();
        date.toLocaleTimeString().replace(/ ?(AM|PM)/, "") + date.getMilliseconds();
        var ms = "000" + date.getMilliseconds();
        arguments[0] = date.toLocaleTimeString().replace(/ ?(AM|PM)/, "") + "." + ms.substring(ms.length - 3) + ": " + arguments[0];
        if (Function.prototype.bind && window.console && typeof console.log == "object") {
            console.log = Function.prototype.call.bind(console["log"], console);
        }
        console.log.apply(console, arguments);
    }
};
su.ivcs.media.Console.enabled = true;

su.ivcs.media.VUM = function(stream) {
    var isInstalled = false;
    var vum = null;
    var getTimestamp;
    var source;
    var script;

    var that = this;
    stream.addEventListener("replacetrack", function(event) {
        if (event.detail.newTrack.kind === "audio" && !(vum === null)) {
            that.uninstall();
            su.ivcs.media.Console.log("VUM is destructed due to track is replaced on stream " + stream.id);
        }
    });

    this.getValue = function() {
        if (su.ivcs.media.ie.WebRtcPlugin) {
            return parseFloat(stream.getNativeStream().audio_activity);
        } else {
            if (!isInstalled) {
                this.install();
            }

            var audioContext = su.ivcs.media.getAudioContext();
            if (audioContext.state !== 'running')
            {
                audioContext.resume();
            }

            getTimestamp = new Date().getTime();
            return vum;
        }
    };

    this.install = function() {
        var that = this;
        var audioContext = su.ivcs.media.getAudioContext();
        source = audioContext.createMediaStreamSource(stream);
        script = audioContext.createScriptProcessor(2048, 1, 1);
        script.connect(audioContext.destination);
        script.onaudioprocess = function(event) {
            if (Math.abs(new Date().getTime() - getTimestamp) < 3 * 1000) { // Date.getTime() isn't guarantied to return monotonically increasing value, that's why we use Math.abs
                var array = event.inputBuffer.getChannelData(0);
                var sum = 0.0;
                for (var i = 0; i < array.length; ++i) {
                    sum += array[i] * array[i];
                }
                vum = Math.sqrt(sum / array.length);
            } else {
                that.uninstall();
            }
        };
        source.connect(script);
        vum = 0.0;

        su.ivcs.media.Console.log("VUM is created on stream " + stream.id);
        isInstalled = true;
    };

    this.uninstall = function() {
        source.disconnect();
        script.disconnect();
        vum = null;

        isInstalled = false;
    };

    if (Object.defineProperties) {
        Object.defineProperties(this, {
            value: {
                get: function () {
                    this.getValue();
                }
            }
        });
    }
};

su.ivcs.media.Gain = function(initialStream) {
    var initialAudioTracks = initialStream.getAudioTracks();
    var gainControl = null;

    this.installGain = function() {
        if (gainControl)
        {
            return;
        }

        var audioContext = su.ivcs.media.getAudioContext();
        gainControl = {
            src: audioContext.createMediaStreamSource(initialStream),
            dst: audioContext.createMediaStreamDestination(),
            gainNode: audioContext.createGain()
        };

        gainControl.src.connect(gainControl.gainNode);
        gainControl.gainNode.connect(gainControl.dst);

        gainControl.dst.stream.getAudioTracks().forEach(function(track) {
            initialStream.replaceTrack(track);
        });
    };

    this.deleteGain = function() {
        if (!gainControl)
        {
            return;
        }

        gainControl.gainNode.gain.value = 1;
        gainControl.src.disconnect();
        gainControl.gainNode.disconnect();

        gainControl = null;

        initialAudioTracks.forEach(function(track) {
            initialStream.replaceTrack(track);
        })
    };

    this.getValue = function() {
        return gainControl ? gainControl.gainNode.gain.value : 1;
    };

    this.setValue = function(value) {
        if (value === 1)
        {
            this.deleteGain();
        }
        else
        {
            this.installGain();

            gainControl.gainNode.gain.value = value;
        }
    };

    this.stop = function() {
        this.deleteGain();

        initialStream.stop();
    };
};

su.ivcs.media.getAudioContext = function () {
    if (!su.ivcs.media.audioContext) {
        su.ivcs.media.audioContext = new AudioContext(); // Reuse audio context because in Chrome any page is allowed to have not more than 6 audio contexts
    }
    return su.ivcs.media.audioContext;
};

su.ivcs.media.isGainControlSupported = function() {
    var userAgent = window.navigator.userAgent.toLowerCase();
    if (userAgent.match('firefox') && parseInt(userAgent.match(/firefox\/(.*)/)[1], 10) < 55) {
        return false;
    }

    if (AudioContext && AudioContext.prototype.createGain && AudioContext.prototype.createMediaStreamDestination
        && AudioContext.prototype.createMediaStreamSource && RTCPeerConnection.prototype.hasOwnProperty("addTrack"))
    {
        return true;
    }
    else
    {
        return false;
    }
};

//
// Transform IE WebRTC Plugin API to standard WebRTC API, i.e. define necessary objects and methods:
//
//   su.ivcs.media.ie.RTCPeerConnection
//   su.ivcs.media.ie.RTCSessionDescription
//   su.ivcs.media.ie.RTCIceCandidate
//   su.ivcs.media.ie.getUserMedia
//   su.ivcs.media.ie.MediaStreamTrack
//
su.ivcs.media.ie.RTCSessionDescription = function(description) {
    this.sdp = description.sdp;
    this.type = description.type;
}
su.ivcs.media.ie.RTCSessionDescription.prototype.toString = function() {
    return "type: " + this.type + ", sdp: " + this.sdp;
}

su.ivcs.media.ie.RTCIceCandidate = function(candidate) {
    this.candidate = candidate.candidate;
    this.sdpMLineIndex = candidate.sdpMLineIndex;
    this.sdpMid = candidate.sdpMid;
}
su.ivcs.media.ie.RTCIceCandidate.prototype.toString = function() {
    return "sdpMid: " + this.sdpMid + ", sdpMLineIndex: " + this.sdpMLineIndex + ", candidate: " + this.candidate;
}

su.ivcs.media.ie.getUserMedia = function(constraints, onstream, onfailure) {
    var videoDevice = su.ivcs.media.ie.WebRtcPlugin.getDefaultVideoDevice();
    var audioDevice = su.ivcs.media.ie.WebRtcPlugin.getDefaultAudioDevice();
    var videoConstraints = {};
    var audioConstraints = {};
    if (constraints) {
        if (constraints.video !== undefined) {
            if (!constraints.video) {
                videoDevice = null;
            } else {
                if (constraints.video.optional) {
                    for (var i = 0; i < constraints.video.optional.length; i++) {
                        var optional = constraints.video.optional[i];
                        if (optional.sourceId && su.ivcs.media.ie.WebRtcPlugin.getDevices()[optional.sourceId]) {
                            videoDevice = su.ivcs.media.ie.WebRtcPlugin.getDevices()[optional.sourceId];
                        }
                        for (var property in optional) {
                            videoConstraints[property] = optional[property];
                        }
                    }
                }
                if (constraints.video.mandatory) {
                    for (var property in constraints.video.mandatory) {
                        videoConstraints[property] = constraints.video.mandatory[property];
                    }
                    if (constraints.video.mandatory.chromeMediaSource && constraints.video.mandatory.chromeMediaSource.match(/screen|screenarea|window/)) {
                        videoDevice = new su.ivcs.media.ie.WebRtcPlugin.ScreenSharingDevice();
                    }
                }
                if (videoDevice) {
                    videoDevice.setConstraints(videoConstraints);
                }
            }
        }
        if (constraints.audio !== undefined) {
            if (!constraints.audio) {
                audioDevice = null;
            } else {
                if (constraints.audio.optional) {
                    for (var i = 0; i < constraints.audio.optional.length; i++) {
                        var optional = constraints.audio.optional[i];
                        if (optional.sourceId && su.ivcs.media.ie.WebRtcPlugin.getDevices()[optional.sourceId]) {
                            audioDevice = su.ivcs.media.ie.WebRtcPlugin.getDevices()[optional.sourceId];
                        }
                    }
                }
                if (audioDevice) {
                    audioDevice.setConstraints(audioConstraints);
                }
            }
        }
    }
    if (videoDevice && videoDevice.id == "screensharing") {
        videoDevice.chooseWindow(function(chosen) {
            if (chosen) {
                onstream(su.ivcs.media.ie.WebRtcPlugin.createLocalMediaStream(videoDevice, null));
            } else {
                onfailure({ constraintName: "", message: "Screen sharing was canceled", name: "DeviceCaptureError"});
            }
        });
    } else {
        window.setTimeout(function() {
            try {
                var stream = su.ivcs.media.ie.WebRtcPlugin.createLocalMediaStream(videoDevice, audioDevice);
                onstream(stream);
            } catch (exception) {
                var noSpeakers = !su.ivcs.media.ie.WebRtcPlugin.getDefaultSpeakerDevice();
                var errorMessage = exception.message;
                if (!noSpeakers && errorMessage === "")
                {
                    if (constraints.video !== undefined && constraints.video) {
                        errorMessage = "Could not start video source";
                    }
                    else if (constraints.audio !== undefined && constraints.audio) {
                        errorMessage = "Could not start audio source";
                    }
                }
                onfailure({ constraintName: "", message: errorMessage, name: noSpeakers ? "NoSpeakersDeviceCaptureError" : "DeviceCaptureError"});
            }
        }, 0);
    }
}

su.ivcs.media.ie.MediaStreamTrack = (function() {
    return {

        getSources: function(onsources) {
            if (window.console && window.console.warn) {
                window.console.warn("su.ivcs.media.ie.MediaStreamTrack.getSources is deprecated and will be removed soon, use su.ivcs.media.enumerateDevices instead");
            }
            window.setTimeout(function() {
                var sources = [];
                for (var id in su.ivcs.media.ie.WebRtcPlugin.getDevices()) {
                    sources[sources.length] = {
                        id: su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].id,
                        label: su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].label,
                        kind: su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].kind,
                        toString: function() {
                            return "id: " + this.id + ", kind: " + this.kind + ", label: " + this.label;
                        }
                    };
                }
                onsources(sources);
            }, 0);
        },

        onsourceschange: function() {}

    };
})();

su.ivcs.media.ie.RTCPeerConnection = function(configuration) {
    var that = this;
    this.iceConnectionState = "new";
    this.pc = su.ivcs.media.ie.WebRtcPlugin.createPeerConnection(configuration);
    this.pc.onicecandidate = function(candidate) {
        var event = candidate ? { candidate: new su.ivcs.media.ie.RTCIceCandidate({ candidate: candidate.candidate, sdpMLineIndex: candidate.index , sdpMid: candidate.mid }) } : { candidate: null };
        that.onicecandidate(event);
    };
    this.pc.onaddstream = function(ieStream) {
        var stream = su.ivcs.media.ie.WebRtcPlugin.createRemoteMediaStream(ieStream);
        var audioTracks = stream.getAudioTracks();
        var videoTracks = stream.getVideoTracks();
        for (var i = 0; i < audioTracks.length; i++) {
            that.ontrack({streams: [stream], track: audioTracks[i]})
        }
        for (i = 0; i < videoTracks.length; i++) {
            that.ontrack({streams: [stream], track: videoTracks[i]});
        }
    };
    this.pc.oniceconnectionstatechange = function(state) {
        that.iceConnectionState = state.toLowerCase();
        that.oniceconnectionstatechange({});
    };
}
su.ivcs.media.ie.RTCPeerConnection.prototype.createOffer = function(successCallback, failureCallback, constraints) {
    this.pc.createOffer(successCallback, failureCallback, constraints);
}
su.ivcs.media.ie.RTCPeerConnection.prototype.setLocalDescription = function(description) {
    this.pc.setLocalDescription(description);
}
su.ivcs.media.ie.RTCPeerConnection.prototype.setRemoteDescription = function(description) {
    this.pc.setRemoteDescription(description);
}
su.ivcs.media.ie.RTCPeerConnection.prototype.addIceCandidate = function(candidate) {
    this.pc.addIceCandidate(candidate);
}
su.ivcs.media.ie.RTCPeerConnection.prototype.addStream = function(stream) {
    this.pc.addStream(stream.getNativeStream());
}
su.ivcs.media.ie.RTCPeerConnection.prototype.close = function() {
    this.pc.close();
}
su.ivcs.media.ie.RTCPeerConnection.prototype.getStats = function() {
    return this.pc.getStats();
}
su.ivcs.media.ie.RTCPeerConnection.prototype.onicecandidate = function(event) {}
su.ivcs.media.ie.RTCPeerConnection.prototype.onaddstream = function(event) {}
su.ivcs.media.ie.RTCPeerConnection.prototype.ontrack = function(event) {}
su.ivcs.media.ie.RTCPeerConnection.prototype.oniceconnectionstatechange = function(event) {}

if (navigator.userAgent.match(/Trident\/7/) || window.ActiveXObject || "ActiveXObject" in window) {


    // IE8 support (MDN's polyfill)
    if (!Function.prototype.bind) {
        Function.prototype.bind = function (object) {
            var that = this;
            var args = Array.prototype.slice.call(arguments, 1);
            var nop = function () {};
            var bound = function () {
                return that.apply(this instanceof nop && object ? this : object, args.concat(Array.prototype.slice.call(arguments)));
            };
            nop.prototype = this.prototype;
            bound.prototype = new nop();
            return bound;
        };
    }

    // IE8 support (MDN's polyfill)
    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function (searchElement, fromIndex) {
          var k, o = Object(this);
          var length = o.length >>> 0;
          if (length === 0) {
            return -1;
          }
          var n = +fromIndex || 0;
          if (Math.abs(n) === Infinity) {
            n = 0;
          }
          if (n >= length) {
            return -1;
          }
          k = Math.max(n >= 0 ? n : length - Math.abs(n), 0);
          while (k < length) {
            var kValue;
            if (k in o && o[k] === searchElement) {
              return k;
            }
            k++;
          }
          return -1;
        };
    }

    su.ivcs.media.createVideo = function() {
        var video = document.createElement("object");
        video.classid = "clsid:03752221-13E8-4B7B-9392-CCAA5703ABBC";
        video.setStream = function(stream) {
            if (video.stream) {
                video.stream.detachFrom(video);
                video.stream = null;
            }
            if (stream) {
                stream.attachTo(video);
                video.stream = stream;
            }
        };
        video.initialize = function() {
            video.init(su.ivcs.media.ie.WebRtcPlugin.getAxo());
        };
        video.setSinkId = function(sinkId) {
            su.ivcs.media.ie.WebRtcPlugin.getAxo().get_device_manager().set_output_device_name(sinkId); // This works because sinkId (MediaDeviceInfo.deviceId) equals to (MediaDeviceInfo.label) for IE Plugin
        };
        video.play = function () {};
        return video;
    };

    su.ivcs.media.createAudio = su.ivcs.media.createVideo;

    su.ivcs.media.enumerateDevices = function(ondevices, onfailure) {
        window.setTimeout(function() {
            var devices = [];
            for (var id in su.ivcs.media.ie.WebRtcPlugin.getDevices()) {
                devices[devices.length] = {
                    deviceId: su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].id,
                    kind: su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].kind == "audio" ? "audioinput" :
                        su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].kind == "video" ? "videoinput" : "audiooutput",
                    label: su.ivcs.media.ie.WebRtcPlugin.getDevices()[id].label,
                    toString: function() {
                        return "id: " + this.deviceId + ", kind: " + this.kind + ", label: " + this.label;
                    }
                };
            }
            ondevices(devices);
        }, 0);
    }

    su.ivcs.media.ie.fixLocalSdp = function(sdp) {
        var redRegexp = /a=rtpmap\:(\d+)\sred\/8000\r?\n?/;
        var match = redRegexp.exec(sdp);
        if (match && match.length > 1) {
            sdp = sdp.replace(new RegExp('(m=audio.*)(\\s' + match[1] + ')(.*)'), '$1$3');
            sdp = sdp.replace(redRegexp, '');
        }
        return sdp;
    };

    su.ivcs.media.ie.fixRemoteSdp = function(sdp) {
        return sdp;
    };

    su.ivcs.media.ie.fixLocalCandidate = function(candidate) {
        return candidate;
    };

    su.ivcs.media.ie.fixRemoteCandidate = function(candidate) {
        return candidate;
    };

    su.ivcs.media.ie.WebRtcPlugin = (function() {
        var devices = null;
        var defaultVideoDevice = null;
        var defaultAudioDevice = null;
        var defaultSpeakerDevice = null;
        var axo = null;
        var webRtcPlugin = {
            version: "1.1",
            peerConnections: {},
            lastUsedPeerConnectionId: 0,
            streams: {},
            lastUsedStreamId: 0,
            getAxo: function() {
                if (!axo) {
                    try {
                        axo = new ActiveXObject("iva_webrtc_plugin.plugin." + this.version);
                        axo.init();
                        axo.on_devices_change = function(dm) {
                            devices = null;
                            su.ivcs.media.ie.MediaStreamTrack.onsourceschange();
                        }
                        su.ivcs.media.Console.log("WebRTC's ActiveXObject version " + this.version + " initialized");
                    } catch (exception) {
                        su.ivcs.media.Console.log("WebRTC's ActiveXObject can't be initialized, because it isn't installed yet");
                    }
                }
                return axo;
            },
            getDevices: function() {
                if (!devices) {
                    devices = {};
                    defaultVideoDevice = null;
                    defaultAudioDevice = null;
                    var dm = this.getAxo().get_device_manager();
                    for (var i = 0, device = null; (device = dm.get_video_device(i)); i++) {
                        devices[device.name] = new su.ivcs.media.ie.WebRtcPlugin.VideoDevice(device);
                        if (!defaultVideoDevice) {
                            defaultVideoDevice = devices[device.name];
                        }
                    }
                    for (var i = 0, device = null; (device = dm.get_audio_device(i)); i++) {
                        devices[device.name] = new su.ivcs.media.ie.WebRtcPlugin.AudioDevice(device);
                        if (!defaultAudioDevice) {
                            defaultAudioDevice = devices[device.name];
                        }
                    }
                    for (var i = 0, deviceName = null; (deviceName = dm.get_output_device_name(i)); i++) {
                        devices[deviceName] = new su.ivcs.media.ie.WebRtcPlugin.SpeakerDevice(deviceName);
                        if (!defaultSpeakerDevice) {
                            defaultSpeakerDevice = devices[deviceName];
                        }
                    }
                    su.ivcs.media.Console.log("WebRTC sources:");
                    for (var id in devices) {
                        su.ivcs.media.Console.log("  " + devices[id]);
                    }
                }
                return devices;
            },
            setSpeaker: function(deviceName) {
                var dm = this.getAxo().get_device_manager();
                dm.set_output_device_name(deviceName);
            },
            getDefaultVideoDevice: function() {
                this.getDevices();
                return defaultVideoDevice;
            },
            getDefaultAudioDevice: function() {
                this.getDevices();
                return defaultAudioDevice;
            },
            getDefaultSpeakerDevice: function() {
                this.getDevices();
                return defaultSpeakerDevice;
            }
        };
        return webRtcPlugin;
    })();
    su.ivcs.media.ie.WebRtcPlugin.isInstalled = function() {
        return this.getAxo();
    }
    su.ivcs.media.ie.WebRtcPlugin.installFrom = function(url) {
        var id = "296E26E7-B93E-4454-80A8-BC5B5A2815EE";
        var object = document.getElementById(id);
        if (object) {
            document.body.removeChild(object);
        }
        object = document.createElement("object");
        object.id = id;
        object.codeBase = url + "/iva_webrtc_plugin_" + this.version.replace(".", "_") + ".cab#version=" + this.version.replace(".", ",") + ",0,0";
        object.classid = "clsid:" + id;
        object.style.display = "none";
        document.body.appendChild(object);
    }
    su.ivcs.media.ie.WebRtcPlugin.logTo = function(logFilePath) {
        this.getAxo().stop_debug();
        if (logFilePath) {
            this.getAxo().start_debug(logFilePath);
        }
    }
    su.ivcs.media.ie.MediaStream = {};
    su.ivcs.media.ie.MediaStream = function(id, stream) {
        this.id = id;
        this.stream = stream;
        this.elements = [];
        this.eventTarget = document.createDocumentFragment();

        su.ivcs.media.ie.MediaStream.prototype.attachTo = function(element)
        {
            element.attach_stream(this.stream);
            this.elements[this.elements.length] = element;
        };

        su.ivcs.media.ie.MediaStream.prototype.detachFrom = function(element)
        {
            element.detach_stream();
            var index = this.elements.indexOf(element);
            if (index > -1) {
                this.elements.splice(index, 1);
            }
        };

        su.ivcs.media.ie.MediaStream.prototype.stop = function(){};

        su.ivcs.media.ie.MediaStream.prototype.getVideoTracks = function()
        {
            if (!this.stream.video) {
                return [];
            }
            return [this.stream.video];
        };

        su.ivcs.media.ie.MediaStream.prototype.getAudioTracks = function()
        {
            if (!this.stream.audio) {
                return [];
            }
            return [this.stream.audio];
        };

        su.ivcs.media.ie.MediaStream.prototype.getTracks = function()
        {
            return [].concat(this.getAudioTracks()).concat(this.getVideoTracks());
        };

        su.ivcs.media.ie.MediaStream.prototype.addTrack = function()
        {
            su.ivcs.media.Console.log("addTrack is not implemented for IE Plugin stream");
        };

        su.ivcs.media.ie.MediaStream.prototype.removeTrack = function()
        {
            su.ivcs.media.Console.log("removeTrack is not implemented for IE Plugin stream");
        };

        su.ivcs.media.ie.MediaStream.prototype.addEventListener = function(type, listener, useCapture, wantsUntrusted)
        {
            return this.eventTarget.addEventListener(type, listener, useCapture, wantsUntrusted);
        };

        su.ivcs.media.ie.MediaStream.prototype.dispatchEvent = function(event)
        {
            return this.eventTarget.dispatchEvent(event);
        };

        su.ivcs.media.ie.MediaStream.prototype.removeEventListener = function(type, listener, useCapture)
        {
            return this.eventTarget.removeEventListener(type, listener, useCapture);
        };

        su.ivcs.media.ie.MediaStream.prototype.getNativeStream = function()
        {
            return this.stream;
        };

        su.ivcs.media.ie.MediaStream.prototype.toString = function()
        {
            return "IE WebRTC local stream " + this.id;
        };
    };
    su.ivcs.media.ie.WebRtcPlugin.createLocalMediaStream = function(video, audio) {
        var elements = [];
        var id = ++this.lastUsedPeerConnectionId;
        var stream = this.getAxo().get_user_media();
        if (video) {
            try {
                video.acquire();
            } catch (exception) {
                throw new Error("Video device '" + video + "' can't be acquired");
            }
            stream.attach_video(video.nativeDevice);
        }
        if (audio) {
            try {
                audio.acquire();
            } catch (exception) {
                throw new Error("Audio device '" + audio + "' can't be acquired");
            }
            stream.attach_audio(audio.nativeDevice);
        }
        var that = this;

        var mediaStream = new su.ivcs.media.ie.MediaStream(id, stream);
        mediaStream.stop = function()
        {
            if (video) {
                stream.detach_video();
                video.release();
            }
            if (audio) {
                stream.detach_audio();
                audio.release();
            }
            stream.release();
            delete that.streams[id];
            for (var i = 0; i < elements.length; i++) {
                elements[i].detach_stream();
            }
        };
        this.streams[id] = mediaStream;
        return this.streams[id];
    };
    su.ivcs.media.ie.WebRtcPlugin.createRemoteMediaStream = function(stream) {
        var elements = [];
        var id = ++this.lastUsedPeerConnectionId;
        var that = this;

        var mediaStream = new su.ivcs.media.ie.MediaStream(id, stream);
        mediaStream.stop = function()
        {
            stream.release();
            delete that.streams[id];
            for (var i = 0; i < elements.length; i++) {
                elements[i].detach_stream();
            }
        };
        this.streams[id] = mediaStream;
        return this.streams[id];
    };
    su.ivcs.media.ie.WebRtcPlugin.createPeerConnection = function(configuration) {
        var that = this;
        var im = that.getAxo().create_ice_manager();
        if (configuration && configuration.iceServers) {
            for (var i = 0; i < configuration.iceServers.length; i++) {
                var server = configuration.iceServers[i];
                if (server.url) {
                    im.add_server(server.url, !server.username ? "" : server.username, !server.credential ? "" : server.credential);
                }
            }
        }
        var nativePc = that.getAxo().create_peer_connection(im);
        var pc = {

            ondescription: function() {},

            createOffer: function(successCallback, errorCallback, constraints) {
                this.ondescription = successCallback;
                var offerToReceiveAudio = true;
                var offerToReceiveVideo = true;
                if (constraints) {
                    if (constraints.offerToReceiveAudio !== undefined) {
                        offerToReceiveAudio = !!constraints.offerToReceiveAudio;
                    }
                    if (constraints.offerToReceiveVideo !== undefined) {
                        offerToReceiveVideo = !!constraints.offerToReceiveVideo;
                    }
                }
                nativePc.create_offer(offerToReceiveAudio, offerToReceiveVideo);
            },

            setLocalDescription: function(description) {
                nativePc.local_description = nativePc.create_session_description(description.type, description.sdp);
            },

            setRemoteDescription: function(description) {
                nativePc.remote_description = nativePc.create_session_description(description.type, description.sdp);
            },

            addIceCandidate: function(candidate) {
                nativePc.add_ice_candidate(nativePc.create_ice_candidate(candidate.sdpMid, candidate.sdpMLineIndex, candidate.candidate));
            },

            addStream: function(stream) {
                nativePc.add_stream(stream);
            },

            close: function() {
                nativePc.close();
            },

            getStats: function() {
                return nativePc.stats;
            },

            onicecandidate: function(candidate) {},

            onaddstream: function(stream) {},

            oniceconnectionstatechange: function(event) {}

        };
        nativePc.on_session_description = function(description) {
            pc.ondescription(new su.ivcs.media.ie.RTCSessionDescription({ sdp: description.sdp, type: description.type }));
        };
        nativePc.on_ice_candidate = function(candidate) {
            pc.onicecandidate(candidate);
        };
        nativePc.on_media_stream = function(stream) {
            pc.onaddstream(stream);
        };
        nativePc.on_ice_connection_change = function(state) {
            pc.oniceconnectionstatechange(state);
        };
        return pc;
    }

    su.ivcs.media.ie.WebRtcPlugin.AbstractDevice = function(device, kind) {
        this.nativeDevice = device;
        this.kind = kind;
        this.id = device && device.name || ""; // support prototyping
        this.label = device && device.name || ""; // support prototyping
    }
    su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.setConstraints = function(constraints) {
        for (var property in constraints) {
            this.constraints[property] = constraints[property];
        }
    }
    su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.acquire = function() {}
    su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.release = function() {}
    su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.toNative = function() {
        return this.device;
    }
    su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.toString = function() {
        return "kind: " + this.kind + ", label: " + this.label;
    }

    su.ivcs.media.ie.WebRtcPlugin.VideoDevice = function(device) {
        su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.call(this, device, "video");
        this.acquisitions = 0;
        this.setConstraints({});
    }
    su.ivcs.media.ie.WebRtcPlugin.VideoDevice.prototype = new su.ivcs.media.ie.WebRtcPlugin.AbstractDevice();
    su.ivcs.media.ie.WebRtcPlugin.VideoDevice.prototype.setConstraints = function(constraints) {
        this.constraints = {}; // FIXME: How to reset camera capture mode, if passed 'constraints' is empty?
        su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.setConstraints.call(this, constraints);
    }
    su.ivcs.media.ie.WebRtcPlugin.VideoDevice.prototype.acquire = function() {
        if (++this.acquisitions === 1) {
            for (var property in this.constraints) {
                if (property.match(/minWidth|maxWidth|minHeight|maxHeight|minFrameRate|maxFrameRate|minAspectRatio|maxAspectRatio/)) {
                    this.nativeDevice[property.replace(/[A-Z]/g, "_$&").toLowerCase()] = this.constraints[property];
                }
            }
        }
    }
    su.ivcs.media.ie.WebRtcPlugin.VideoDevice.prototype.release = function() {
        if (this.acquisitions > 0) {
            this.acquisitions--;
        }
    }

    su.ivcs.media.ie.WebRtcPlugin.AudioDevice = function(device) {
        su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.call(this, device, "audio");
    }
    su.ivcs.media.ie.WebRtcPlugin.AudioDevice.prototype = new su.ivcs.media.ie.WebRtcPlugin.AbstractDevice();
    su.ivcs.media.ie.WebRtcPlugin.AudioDevice.prototype.setConstraints = function(constraints) {}

    su.ivcs.media.ie.WebRtcPlugin.ScreenSharingDevice = function() {
        this.nativeDevice = su.ivcs.media.ie.WebRtcPlugin.getAxo().create_screen_sharing();
        this.kind = "video";
        this.id = "screensharing";
        this.label = "Screen Sharing";
    }
    su.ivcs.media.ie.WebRtcPlugin.ScreenSharingDevice.prototype = new su.ivcs.media.ie.WebRtcPlugin.AbstractDevice();
    su.ivcs.media.ie.WebRtcPlugin.ScreenSharingDevice.prototype.setConstraints = function(constraints) {
        this.constraints = {
            chromeMediaSource: "screen",
            ivcsShowCursor: true,
            ivcsVisualizeClick: false
        };
        su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.prototype.setConstraints.call(this, constraints);
        this.nativeDevice.capture_mode = this.constraints.chromeMediaSource === "screenarea" ? 0 : this.constraints.chromeMediaSource === "window" ? 2 : 1;
        this.nativeDevice.show_cursor = !!this.constraints.ivcsShowCursor ? 1 : 0;
        this.nativeDevice.visualize_click = !!this.constraints.ivcsVisualizeClick ? 1 : 0;
        for (var property in this.constraints) {
            if (property.match(/minWidth|maxWidth|minHeight|maxHeight|minFrameRate|maxFrameRate|minAspectRatio|maxAspectRatio/)) {
                this.nativeDevice[property.replace(/[A-Z]/g, "_$&").toLowerCase()] = this.constraints[property];
            }
        }
    }
    su.ivcs.media.ie.WebRtcPlugin.ScreenSharingDevice.prototype.chooseWindow = function(onwindowchosen) {
        this.nativeDevice.on_choose_window = function(chosen) {
            onwindowchosen(chosen);
        }
        this.nativeDevice.choose_window();
    }

    su.ivcs.media.ie.WebRtcPlugin.SpeakerDevice = function(deviceName) {
        var device = {
            name: deviceName
        };
        su.ivcs.media.ie.WebRtcPlugin.AbstractDevice.call(this, device, "speaker");
    };
    su.ivcs.media.ie.WebRtcPlugin.SpeakerDevice.prototype = new su.ivcs.media.ie.WebRtcPlugin.AbstractDevice();
    su.ivcs.media.ie.WebRtcPlugin.SpeakerDevice.prototype.setConstraints = function(constraints) {};

    su.ivcs.media.WebRtcClient.prototype.getStats = function(uri) {
        if (this.subscriptions[uri]) {
            try {
                var stats = this.subscriptions[uri].pc.getStats();
                return {
                    availableBandwidth: parseInt(stats.available_bandwidth),
                    transportType: stats.transport_type ? stats.transport_type : null,
                    video: {
                        bitrate: parseInt(stats.video_bitrate),
                        bytesReceived: parseInt(stats.video_bytes_received),
                        packetsLost: parseInt(stats.video_packets_lost)
                    },
                    audio: {
                        bitrate: parseInt(stats.audio_bitrate),
                        bytesReceived: parseInt(stats.audio_bytes_received),
                        packetsLost: parseInt(stats.audio_packets_lost)
                    },
                    lastFailure: this.subscriptions[uri].stats.lastFailure,
                    supportedStats: IE_SUBSCRIPTION_STATS
                };
            } catch (exception) {
                return this.subscriptions[uri].stats;
            }
        } else if (this.primaryPublications[uri]) {
            try {
                var stats = this.primaryPublications[uri].pc.getStats();
                return {
                    availableBandwidth: parseInt(stats.available_bandwidth),
                    transportType: stats.transport_type ? stats.transport_type : null,
                    video: {
                        bitrate: parseInt(stats.video_bitrate),
                        bytesSent: parseInt(stats.video_bytes_sent),
                        rtt: parseInt(stats.video_rtt)
                    },
                    audio: {
                        bitrate: parseInt(stats.audio_bitrate),
                        bytesSent: parseInt(stats.audio_bytes_sent),
                        rtt: parseInt(stats.audio_rtt)
                    },
                    lastFailure: this.primaryPublications[uri].stats.lastFailure,
                    supportedStats: IE_PUBLICATION_STATS
                };
            } catch (exception) {
                return this.subscriptions[uri].stats;
            }
        } else {
            return EMPTY_STATS;
        }
    };

}

navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || su.ivcs.media.ie.getUserMedia;
window.RTCPeerConnection = window.RTCPeerConnection || window.webkitRTCPeerConnection || window.mozRTCPeerConnection || su.ivcs.media.ie.RTCPeerConnection;
window.RTCSessionDescription = window.RTCSessionDescription || window.webkitRTCSessionDescription || window.mozRTCSessionDescription || su.ivcs.media.ie.RTCSessionDescription;
window.RTCIceCandidate = window.RTCIceCandidate || window.webkitRTCIceCandidate || window.mozRTCIceCandidate || su.ivcs.media.ie.RTCIceCandidate;
window.MediaStreamTrack = window.MediaStreamTrack || su.ivcs.media.ie.MediaStreamTrack;
window.AudioContext = window.AudioContext || window.webkitAudioContext;


//////////////// Do not merge content below
su.ivcs.media.enhanceStream = function(stream) {
    var initialAudioTracks = stream.getAudioTracks();
    var initialVideoTracks = stream.getVideoTracks();

    if (!stream.stop)
    {
        stream.stop = function() {
            stream.getVideoTracks().forEach(function (track) {
                if (track.stop) {
                    track.stop();
                }
            });
            stream.getAudioTracks().forEach(function (track) {
                if (track.stop) {
                    track.stop();
                }
            })
        };
    }

    if (!stream.onreplacetrack)
    {
        stream.onreplacetrack = function(){};
    }

    stream.replaceTrack = function (newTrack) {
        stream.getTracks().slice().forEach(function(track) {
            if (track.kind === newTrack.kind) {
                stream.removeTrack(track);
                stream.addTrack(newTrack);

                stream.onreplacetrack(newTrack);
                stream.dispatchEvent(new CustomEvent("replacetrack", {detail: {oldTrack: track, newTrack: newTrack}}));
            }
        });
    };

    stream.setVideoEnabled = function(enabled) {
        initialVideoTracks.concat(stream.getVideoTracks()).forEach(function(track) {
            track.enabled = enabled;
        });
    };

    stream.setAudioEnabled = function(enabled) {
        //  FF bug
        if (navigator.userAgent.match('Firefox'))
        {
            setTimeout(function() {
                initialAudioTracks.concat(stream.getAudioTracks()).forEach(function(track) {
                    track.enabled = enabled;
                });
            }, 0);
        }
        else
        {
            initialAudioTracks.concat(stream.getAudioTracks()).forEach(function(track) {
                track.enabled = enabled;
            });
        }
    };

    return stream;
};
su.ivcs.media.enhanceStreamFunction = function(onStreamFunction, enhanceStreamFunction) {
    return function(stream)
    {
        stream = su.ivcs.media.enhanceStream(stream);
        if (enhanceStreamFunction)
        {
            stream = enhanceStreamFunction(stream);
        }
        onStreamFunction(stream);
    };
};

navigator.legacyGetUserMedia = navigator.getUserMedia;
su.ivcs.media.getUserMedia = function(constraints, onSuccess, onFailure)
{
    var gainControl = su.ivcs.media.isGainControlSupported()
        && constraints.audio && typeof constraints.audio === 'object'
        && "gainControl" in constraints.audio && constraints.audio.gainControl;
    onSuccess = su.ivcs.media.enhanceStreamFunction(onSuccess, function (stream) {
        if (gainControl) {
            stream.gain = new su.ivcs.media.Gain(stream);
        }
        return stream;
    });

    var updatedFailure = function(error) {
        if (typeof error == "string") {
            onFailure({name: error, message: error});
        }
        else {
            onFailure(error);
        }
    };
    // New getUserMedia
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia)
    {
        var deleteOldConstraints = function(constraint) {
            delete constraint.optional;
            delete constraint.mandatory;
        };
        if (constraints.video) deleteOldConstraints(constraints.video);
        if (constraints.video && constraints.video.advanced)
        {
            for (var index = 0; index < constraints.video.advanced.length; index++)
            {
                deleteOldConstraints(constraints.video.advanced[index]);
            }
        }
        if (constraints.audio) deleteOldConstraints(constraints.audio);

        navigator.mediaDevices.getUserMedia(constraints).then(onSuccess)["catch"](updatedFailure);
    }
    // Legacy getUserMedia
    else
    {
        var deleteNewConstraints = function(constraint) {
            for (var field in constraint) {
                if (field != 'mandatory' && field != 'optional') {
                    delete constraint[field];
                }
            }
        };
        if (constraints.video) deleteNewConstraints(constraints.video);
        if (constraints.audio) deleteNewConstraints(constraints.audio);

        navigator.legacyGetUserMedia(constraints, onSuccess, updatedFailure);
    }
};

if (typeof window.MediaStreamTrack.getSources == 'undefined')
{
    window.MediaStreamTrack.getSources = function(onsources) {
        window.setTimeout(function() {
            var sources = [{id: "camera", label: "Default camera", kind: "video"}, {id: "mic", label: "Default microphone", kind: "audio"}];
            onsources(sources);
        }, 0);
    };
}
else if (window.navigator.userAgent.match('OPR'))
{
    var getSourcesInitial = window.MediaStreamTrack.getSources;
    window.MediaStreamTrack.getSources = function(onsources) {
        getSourcesInitial(function(sources)
        {
            var result = [];
            for (var i = 0; i < sources.length; i++)
            {
                var source = sources[i];
                var id = source.id;
                var label = source.label;
                var kind = source.kind;
                if (label === undefined || label === '')
                {
                    label = (kind === 'audio' ? 'Microphone-' : 'Camera-') + id.substr(0, 6);
                }
                result.push({id: id, label: label, kind: kind});
            }
            onsources(result);
        });
    };
}

var cache = {};

/// screen sharing
window.navigator.getScreenMedia = function (source, width, height, fps, showCursor, visualizeClick, onStream, onFailure) {

    var error;
    var constraints;

    enhancedOnStream = su.ivcs.media.enhanceStreamFunction(onStream);

    onStream = function(stream)
    {
        var onEndedFunc = function(e) {
            var error = error = new Error('NavigatorUserMediaError');
            error.name = 'STREAM_ENDED';
            onFailure(error);
        };
        stream.onended = onEndedFunc;
        stream.getVideoTracks().forEach(function (track) {
            track.onended = onEndedFunc;
        });
        enhancedOnStream(stream);
    };

    var userAgent = window.navigator.userAgent.toLowerCase();

    if ((navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) || navigator.getDisplayMedia) {

        switch (source)
        {
            case 'screen':
                source = 'monitor';
                break;
            case 'screenarea':
                source = 'application';
                break;
            case 'window':
                source = 'window';
                break;
            default:
                source = 'application';
                break;
        }

        constraints = {
            video: {
                displaySurface: source,
                cursor: showCursor ? 'always' : 'never',
                width: {max: width},
                frameRate: {max: fps}
            }
        };

        if (navigator.mediaDevices.getDisplayMedia)
        {
            navigator.mediaDevices.getDisplayMedia(constraints).then(onStream)["catch"](onFailure);
        }
        else if (navigator.getDisplayMedia)
        {
            navigator.getDisplayMedia(constraints).then(onStream)["catch"](onFailure);
        }
    }
};


if (window.navigator.userAgent.match('Chrome')) {
    window.addEventListener('message', function (event) {
        if (event.origin != window.location.origin) {
            return;
        }
        if (event.data.type == 'gotScreen' && cache[event.data.id]) {
            var data = cache[event.data.id];

            var width = data[0];
            var height = data[1];
            var fps = data[2];
            var onstream = data[3];
            var onfailure = data[4];


            delete cache[event.data.id];

            if (event.data.sourceId === '') { // user canceled
                var error = error = new Error('NavigatorUserMediaError');
                error.name = 'USER_CANCELLED';
                onfailure(error);
            } else {
                var constraints =  {audio: false, video: {mandatory: {
                    chromeMediaSource: 'desktop',
                    chromeMediaSourceId: event.data.sourceId,
                    maxWidth: width,
                    maxHeight: height,
                    minFrameRate: fps
                }}};
                window.navigator.legacyGetUserMedia(constraints, onstream, onfailure);
            }
        } else if (event.data.type == 'getScreenPending') {
            window.clearTimeout(event.data.id);
        }
    });

}

// Helper method to munge an SDP to enable simulcasting (Chrome only)
function mungeSdpForSimulcasting(sdp) {
    // Let's munge the SDP to add the attributes for enabling simulcasting
    // (based on https://gist.github.com/ggarber/a19b4c33510028b9c657)
    var lines = sdp.split("\r\n");
    var video = false;
    var ssrc = [ -1 ], ssrc_fid = [ -1 ];
    var cname = null, msid = null, mslabel = null, label = null;
    var insertAt = -1;
    for(var i=0; i<lines.length; i++) {
        var mline = lines[i].match(/m=(\w+) */);
        if(mline) {
            var medium = mline[1];
            if(medium === "video") {
                // New video m-line: make sure it's the first one
                if(ssrc[0] < 0) {
                    video = true;
                } else {
                    // We're done, let's add the new attributes here
                    insertAt = i;
                    break;
                }
            } else {
                // New non-video m-line: do we have what we were looking for?
                if(ssrc[0] > -1) {
                    // We're done, let's add the new attributes here
                    insertAt = i;
                    break;
                }
            }
            continue;
        }
        if(!video)
            continue;
        var sim = lines[i].match(/a=ssrc-group:SIM (\d+) (\d+) (\d+)/);
        if(sim) {
            su.ivcs.media.Console.log("The SDP already contains a SIM attribute, munging will be skipped");
            return sdp;
        }
        var fid = lines[i].match(/a=ssrc-group:FID (\d+) (\d+)/);
        if(fid) {
            ssrc[0] = fid[1];
            ssrc_fid[0] = fid[2];
            lines.splice(i, 1); i--;
            continue;
        }
        if(ssrc[0]) {
            var match = lines[i].match('a=ssrc:' + ssrc[0] + ' cname:(.+)')
            if(match) {
                cname = match[1];
            }
            match = lines[i].match('a=ssrc:' + ssrc[0] + ' msid:(.+)')
            if(match) {
                msid = match[1];
            }
            match = lines[i].match('a=ssrc:' + ssrc[0] + ' mslabel:(.+)')
            if(match) {
                mslabel = match[1];
            }
            match = lines[i].match('a=ssrc:' + ssrc[0] + ' label:(.+)')
            if(match) {
                label = match[1];
            }
            if(lines[i].indexOf('a=ssrc:' + ssrc_fid[0]) === 0) {
                lines.splice(i, 1); i--;
                continue;
            }
            if(lines[i].indexOf('a=ssrc:' + ssrc[0]) === 0) {
                lines.splice(i, 1); i--;
                continue;
            }
        }
        if(lines[i].length == 0) {
            lines.splice(i, 1); i--;
            continue;
        }
    }
    if(ssrc[0] < 0) {
        // Couldn't find a FID attribute, let's just take the first video SSRC we find
        insertAt = -1;
        video = false;
        for(var i=0; i<lines.length; i++) {
            var mline = lines[i].match(/m=(\w+) */);
            if(mline) {
                var medium = mline[1];
                if(medium === "video") {
                    // New video m-line: make sure it's the first one
                    if(ssrc[0] < 0) {
                        video = true;
                    } else {
                        // We're done, let's add the new attributes here
                        insertAt = i;
                        break;
                    }
                } else {
                    // New non-video m-line: do we have what we were looking for?
                    if(ssrc[0] > -1) {
                        // We're done, let's add the new attributes here
                        insertAt = i;
                        break;
                    }
                }
                continue;
            }
            if(!video)
                continue;
            if(ssrc[0] < 0) {
                var value = lines[i].match(/a=ssrc:(\d+)/);
                if(value) {
                    ssrc[0] = value[1];
                    lines.splice(i, 1); i--;
                    continue;
                }
            } else {
                var match = lines[i].match('a=ssrc:' + ssrc[0] + ' cname:(.+)')
                if(match) {
                    cname = match[1];
                }
                match = lines[i].match('a=ssrc:' + ssrc[0] + ' msid:(.+)')
                if(match) {
                    msid = match[1];
                }
                match = lines[i].match('a=ssrc:' + ssrc[0] + ' mslabel:(.+)')
                if(match) {
                    mslabel = match[1];
                }
                match = lines[i].match('a=ssrc:' + ssrc[0] + ' label:(.+)')
                if(match) {
                    label = match[1];
                }
                if(lines[i].indexOf('a=ssrc:' + ssrc_fid[0]) === 0) {
                    lines.splice(i, 1); i--;
                    continue;
                }
                if(lines[i].indexOf('a=ssrc:' + ssrc[0]) === 0) {
                    lines.splice(i, 1); i--;
                    continue;
                }
            }
            if(lines[i].length === 0) {
                lines.splice(i, 1); i--;
                continue;
            }
        }
    }
    if(ssrc[0] < 0) {
        // Still nothing, let's just return the SDP we were asked to munge
        su.ivcs.media.Console.log("Couldn't find the video SSRC, simulcasting NOT enabled");
        return sdp;
    }
    if(insertAt < 0) {
        // Append at the end
        insertAt = lines.length;
    }
    // Generate a couple of SSRCs (for retransmissions too)
    // Note: should we check if there are conflicts, here?
    ssrc[1] = Math.floor(Math.random()*0xFFFFFFFF);
    ssrc[2] = Math.floor(Math.random()*0xFFFFFFFF);
    ssrc_fid[1] = Math.floor(Math.random()*0xFFFFFFFF);
    ssrc_fid[2] = Math.floor(Math.random()*0xFFFFFFFF);
    // Add attributes to the SDP
    for(var i=0; i<ssrc.length; i++) {
        if(cname) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc[i] + ' cname:' + cname);
            insertAt++;
        }
        if(msid) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc[i] + ' msid:' + msid);
            insertAt++;
        }
        if(mslabel) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc[i] + ' mslabel:' + mslabel);
            insertAt++;
        }
        if(label) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc[i] + ' label:' + label);
            insertAt++;
        }
        // Add the same info for the retransmission SSRC
        if(cname) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc_fid[i] + ' cname:' + cname);
            insertAt++;
        }
        if(msid) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc_fid[i] + ' msid:' + msid);
            insertAt++;
        }
        if(mslabel) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc_fid[i] + ' mslabel:' + mslabel);
            insertAt++;
        }
        if(label) {
            lines.splice(insertAt, 0, 'a=ssrc:' + ssrc_fid[i] + ' label:' + label);
            insertAt++;
        }
    }
    lines.splice(insertAt, 0, 'a=ssrc-group:FID ' + ssrc[2] + ' ' + ssrc_fid[2]);
    lines.splice(insertAt, 0, 'a=ssrc-group:FID ' + ssrc[1] + ' ' + ssrc_fid[1]);
    lines.splice(insertAt, 0, 'a=ssrc-group:FID ' + ssrc[0] + ' ' + ssrc_fid[0]);
    lines.splice(insertAt, 0, 'a=ssrc-group:SIM ' + ssrc[0] + ' ' + ssrc[1] + ' ' + ssrc[2]);
    sdp = lines.join("\r\n");
    if(!sdp.endsWith("\r\n"))
        sdp += "\r\n";
    return sdp;
}
